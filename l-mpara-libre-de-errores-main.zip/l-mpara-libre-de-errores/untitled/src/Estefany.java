public class Estefany {
    public static void main(String[] args) {
        System.out.println("hola mundo");
    }

}
